#include <iostream>
#include <string>

using namespace std;

class Node {
public:
    int intersectionID;
    string currentLightColor;
    int lightDuration[3]; // Red, Yellow, Green
    string trafficLoad;
    bool priorityMode;
    Node* next;
    Node* prev;
};

class TrafficLight {
private:
    Node* head;
    Node* tail;

public:
    TrafficLight() {
        head = NULL;
        tail = NULL;
    }

    void addIntersection() {
        int intersectionID;
        string trafficLoad;
        int redDuration, yellowDuration, greenDuration;

        cout << "Enter intersection ID: ";
        cin >> intersectionID;

        cout << "Enter traffic load (low, medium, high): ";
        cin >> trafficLoad;

        cout << "Enter red light duration (in seconds): ";
        cin >> redDuration;

        cout << "Enter yellow light duration (in seconds): ";
        cin >> yellowDuration;

        cout << "Enter green light duration (in seconds): ";
        cin >> greenDuration;

        Node* newNode = new Node();
        newNode->intersectionID = intersectionID;
        newNode->trafficLoad = trafficLoad;
        newNode->currentLightColor = "Red";
        newNode->lightDuration[0] = redDuration; // Red light duration
        newNode->lightDuration[1] = yellowDuration; // Yellow light duration
        newNode->lightDuration[2] = greenDuration; // Green light duration
        newNode->priorityMode = false;

        if (head == NULL) {
            head = newNode;
            tail = newNode;
            newNode->next = newNode;
            newNode->prev = newNode;
        } else {
            newNode->next = head;
            newNode->prev = tail;
            head->prev = newNode;
            tail->next = newNode;
            tail = newNode;
        }
    }

    void TrafficLightChanges() {
        Node* current = head;
        do {
            if (current->currentLightColor == "Red") {
                current->currentLightColor = "Green";
            } else if (current->currentLightColor == "Green") {
                current->currentLightColor = "Yellow";
            } else if (current->currentLightColor == "Yellow") {
                current->currentLightColor = "Red";
            }
            current = current->next;
        } while (current != head);
    }

    void TrafficDuration(int intersectionID, string newTrafficLoad, int redDuration, int yellowDuration, int greenDuration) {
        Node* current = head;
        do {
            if (current->intersectionID == intersectionID) {
                current->trafficLoad = newTrafficLoad;
                current->lightDuration[0] = redDuration; // Red light duration
                current->lightDuration[1] = yellowDuration; // Yellow light duration
                current->lightDuration[2] = greenDuration; // Green light duration
                break;
            }
            current = current->next;
        } while (current != head);
    }

    void TrafficStatus() {
        Node* current = head;
        do {
            cout << "Intersection " << current->intersectionID << ": "
                 << current->currentLightColor << " ("
                 << getRemainingTime(current->currentLightColor, current->lightDuration) << " seconds remaining)"
                 << endl;
            current = current->next;
        } while (current != head);
    }

    void setPriorityMode(int intersectionID, bool enable) {
        Node* current = head;
        do {
            if (current->intersectionID == intersectionID) {
                current->priorityMode = enable;
                if (enable) {
                    current->lightDuration[2] *= 2;
                } else {
                    current->lightDuration[2] /= 2;
                }
                break;
            }
            current = current->next;
        } while (current != head);
    }

    void TrafficLoad() {
        Node* current = head;
        do {
            if (current->currentLightColor == "Red" && current->lightDuration[0] > 60) {
                Node* nextIntersection = current->next;
                while (nextIntersection != current) {
                    if (nextIntersection->currentLightColor == "Green") {
                        nextIntersection->lightDuration[2] = max(nextIntersection->lightDuration[2] / 2, 15);
                        break;
                    }
                    nextIntersection = nextIntersection->next;
                }
            }
            current = current->next;
        } while (current != head);
    }

private:
    int getRemainingTime(string currentLightColor, int lightDuration[]) {
        if (currentLightColor == "Red") {
            return lightDuration[0];
        } else if (currentLightColor == "Yellow") {
            return lightDuration[1];
        } else {
            return lightDuration[2];
        }
    }
};

int main() {
    TrafficLight tl;

    while (true) {
        cout << "1. Add intersection" << endl;
        cout << "2. Simulate traffic light changes" << endl;
        cout << "3. Adjust traffic light duration" << endl;
        cout << "4. Display traffic light status" << endl;
        cout << "5. Set priority mode" << endl;
        cout << "6. Balance traffic load" << endl;
        cout << "7. Exit" << endl;

        int choice;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                tl.addIntersection();
                break;
            case 2:
                tl.TrafficLightChanges();
                break;
            case 3: {
                int intersectionID;
                string newTrafficLoad;
                int redDuration, yellowDuration, greenDuration;

                cout << "Enter intersection ID: ";
                cin >> intersectionID;

                cout << "Enter new traffic load (low, medium, high): ";
                cin >> newTrafficLoad;

                cout << "Enter new red light duration (in seconds): ";
                cin >> redDuration;

                cout << "Enter new yellow light duration (in seconds): ";
                cin >> yellowDuration;

                cout << "Enter new green light duration (in seconds): ";
                cin >> greenDuration;

                tl.TrafficDuration(intersectionID, newTrafficLoad, redDuration, yellowDuration, greenDuration);
                break;
            }
            case 4:
                tl.TrafficStatus();
                break;
            case 5: {
                int intersectionID;
                bool enable;

                cout << "Enter intersection ID: ";
                cin >> intersectionID;

                cout << "Enable priority mode (1 for yes, 0 for no): ";
                cin >> enable;

                tl.setPriorityMode(intersectionID, enable);
                break;
            }
            case 6:
                tl.TrafficLoad();
                break;
            case 7:
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }

    return 0;
}