 #include<iostream>
 using namespace std;
 
 class Node{
 	private:
 		int value;
 		Node* next;
 	public:
 		void setValue(int value){
 			this->value = value;
		 }
		void setNext(Node* next){
			this->next = next;
		}
		int getValue(){
			return value;
		}
		Node* getNext(){
			return next;
		}
 };