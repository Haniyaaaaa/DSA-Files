#include<iostream>
#include<string>

using namespace std;

class Friend {
private:
    int id;
    string name;
    int mutuals;
    bool suggested;
    Friend *next;
    
public:
    Friend(int i, string n, int m, bool s) : id(i), name(n), mutuals(m), suggested(s), next(NULL) {}
    
    int getId() {
	 return id; 
	 }
    string getName() { 
	return name; 
	}
    int getMutuals() { 
	return mutuals; 
	}
    bool getSuggested() {
	 return suggested;
	  }
    Friend* getNext() {
	 return next; 
	 }
    void setNext(Friend* n) {
	 next = n; 
	 }
    void setSuggested(bool s) { 
	suggested = s;
	 }
    void setMutuals(int m) {
	 mutuals = m; 
	 }
};

class SocialNetwork {
private:
    Friend *start;
    
public:
    SocialNetwork() : start(NULL) {}
    
    void addFriends(int i, string n, int m, bool s) {
        Friend *newProfile = new Friend(i, n, m, s);
        if(start == NULL){
            start = newProfile;
        } else {
            Friend *temp = start;
            while(temp->getNext()) {
                temp = temp->getNext();    
            }
            temp->setNext(newProfile);
        }
    }

    void friendSuggestion() {
        Friend *temp = start;
        while(temp) {
            if(temp->getSuggested()){
                cout << temp->getId() << " - " << temp->getName() << " (" << temp->getMutuals() << " mutuals)\n";
            }
            temp = temp->getNext();
        }
    }
    
    void addAsFriend(int i){
        Friend *temp = start;
        while (temp) {
            if(temp->getId() == i){
                temp->setSuggested(false);
                cout << "Added " << temp->getName() << " as friend\n";
                return;
            }
            temp = temp->getNext();
        }
        cout << "No such user found\n";
    }
    
    void topSuggestion(int n){
        Friend *topSuggestion[n];
        for(int i = 0; i < n; i++){
            topSuggestion[i] = NULL;
        }
        Friend *current = start;
        while(current != NULL){
            for(int i = 0; i < n; i++) {
                if(topSuggestion[i] == NULL || current->getMutuals() > topSuggestion[i]->getMutuals()) {
                    for(int j = n-1; j > i; j--) {
                        topSuggestion[j] = topSuggestion[j-1];
                    }
                    topSuggestion[i] = current;
                    break;
                }
            }
            current = current->getNext();
        }
        cout << "Top " << n << " suggestions based on mutual counts:" << endl;
        for(int i = 0; i < n; i++){
            if(topSuggestion[i] != NULL) {
                cout << "User ID: " << topSuggestion[i]->getId() << ", Name: " << topSuggestion[i]->getName() << ", Mutual Friends: " << topSuggestion[i]->getMutuals() << endl;
            }
        }
    }

    void removeSuggestion(int i){
        Friend *prev = NULL;
        Friend *current = start;
        while(current) {
            if(current->getId() == i) {
                if(prev){
                    prev->setNext(current->getNext());
                }
                else {
                    start = current->getNext();
                }
                delete current;
                cout << "Removed suggestion\n";
                return;
            }
            prev = current;
            current = current->getNext();
        }
        cout << "No such suggestion found\n";
    }    

    void updateMutual(int i, int newCount) {
        Friend *temp = start;
        while(temp){
            if(temp->getId() == i){
                temp->setMutuals(newCount);
                cout << "Updated mutual count for " << temp->getName() << "\n";
                return;
            }
            temp = temp->getNext();
        }
        cout << "No such user found\n";
    }

    void exitNetwork() {
        while(start){
            Friend *temp = start;
            start = start->getNext();
            delete temp;
        }
        cout << "Network cleared\n";
    }  
};

int main() {
    SocialNetwork sn;
    int choice, id, mutuals, n;
    string name;
    
    do{
        cout << "\n1. Add Friend\n2. Show Suggestions\n3. Add as Friend\n4. Top Suggestions\n5. Remove Suggestion\n6. Update Mutual Count\n7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        
        switch(choice) {
            case 1:
                cout << "Enter friend's ID: ";
                cin >> id;
                cout << "Enter friend's name: ";
                cin >> name;
                cout << "Enter mutual friends count: ";
                cin >> mutuals;
                cout << "Is suggested? (1/0): ";
                int suggested;
                cin >> suggested;
                sn.addFriends(id, name, mutuals, suggested);
                break;
            case 2:
                sn.friendSuggestion();
                break;
            case 3:
                cout << "Enter friend's ID: ";
                cin >> id;
                sn.addAsFriend(id);
                break;
            case 4:
                cout << "Enter number of top suggestions: ";
                cin >> n;
                sn.topSuggestion(n);
                break;
            case 5:
                cout << "Enter friend's ID: ";
                cin >> id;
                sn.removeSuggestion(id);
                break;
            case 6:
                cout << "Enter friend's ID: ";
                cin >> id;
                cout << "Enter new mutual friends count: ";
                cin >> mutuals;
                sn.updateMutual(id, mutuals);
                break;
            case 7:
                sn.exitNetwork();
                break;
            default:
                cout << "Invalid choice\n";
        }
    } while(choice != 7);
    
    return 0;
}