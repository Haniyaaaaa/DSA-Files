#include<iostream>
using namespace std;

 class Node{
 	private:
 		int value;
 		Node* next;
 	public:
 		void setValue(int value){
 			this->value = value;
		 }
		void setNext(Node* next){
			this->next = next;
		}
		int getValue(){
			return value;
		}
		Node* getNext(){
			return next;
		}
 };

class LinkedList{
	private:
	Node* head;
	Node* current;
	int size;
	public:
		LinkedList() {
			head = NULL;
			current = NULL;
			size = 0;
		}
	void insert(int value){
		Node *newNode = new Node();
		newNode->setValue(value);
		newNode->setNext(NULL);
		
		if(head == NULL){
			head = newNode;
			current = newNode;
		}
		else{
			current->setNext(newNode);
			current = newNode;
		}
		size++;
	}
	
    void display(){
    	Node *temp = head;
    	while(temp != NULL){
    		cout<<temp->getValue()<<endl;
    		temp = temp->getNext();
		}
	}
	void update(int oldValue, int newValue){
		Node *temp = head;
		while(temp != NULL){
			if(temp->getValue() == oldValue){
				temp->setValue(newValue);
				break;
			}
			temp = temp->getNext();
		}
	}
	void remove(){
		Node *temp = head;
		while( temp != current ){
			if(head == current){
				delete current;
				current = NULL;
				size--;
			}
		}
	}
	void insertOnPosition(int value, int position){
		if(position < 0 || position > size){
			cout<<"Invalid position for insertion"<<endl;
			return;
		}
		Node* newNode = new Node();
		newNode->setValue(value);
		if(position == 0){
			newNode->setNext(head);
			head = newNode;
}

int main(){
	LinkedList listSecA;
	listSecA.insert(100);
	listSecA.insert(60);
	listSecA.display();
	
	
	return 0;
	
}
