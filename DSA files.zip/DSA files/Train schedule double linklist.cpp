#include<iostream>
#include<string>
using namespace std;

class Train {
private:
    int trainNum;
    int depTime;
    int arrTime;
    string route;
    string status;
    Train* prev;
    Train* next;
    
public:
    Train(int t, int dt, int at, string r, string s) : 
        trainNum(t), depTime(dt), arrTime(at), route(r), status(s), prev(nullptr), next(nullptr) {}
    
    int getTrainNum() const { return trainNum; }
    int getDepTime() const { return depTime; }
    int getArrTime() const { return arrTime; }
    string getRoute() const { return route; }
    string getStatus() const { return status; }
    Train* getPrev() const { return prev; }
    Train* getNext() const { return next; }

    void setDepTime(int dt) { depTime = dt; }
    void setArrTime(int at) { arrTime = at; }
    void setStatus(string s) { status = s; }
    void setPrev(Train* p) { prev = p; }
    void setNext(Train* n) { next = n; }
};

class TrainSchedule {
private:
    Train* head;
    Train* tail;

    Train* findTrain(int trainNum) {
        Train* current = head;
        while (current != nullptr) {
            if (current->getTrainNum() == trainNum) return current;
            current = current->getNext();
        }
        return nullptr;
    }

    void insertSorted(Train* newTrain) {
        if (head == nullptr || newTrain->getDepTime() < head->getDepTime()) {
            newTrain->setNext(head);
            if (head) head->setPrev(newTrain);
            head = newTrain;
            if (!tail) tail = newTrain;
        } else {
            Train* current = head;
            while (current->getNext() && current->getNext()->getDepTime() <= newTrain->getDepTime()) {
                current = current->getNext();
            }
            newTrain->setNext(current->getNext());
            newTrain->setPrev(current);
            if (current->getNext()) current->getNext()->setPrev(newTrain);
            current->setNext(newTrain);
            if (current == tail) tail = newTrain;
        }
    }

public:
    TrainSchedule() : head(nullptr), tail(nullptr) {}

    void addTrain(int trainNum, int depTime, int arrTime, string route, string status) {
        Train* newTrain = new Train(trainNum, depTime, arrTime, route, status);
        insertSorted(newTrain);
    }

    void updateTrainStatus(int trainNum, string newStatus) {
        Train* train = findTrain(trainNum);
        if (train) train->setStatus(newStatus);
        else cout << "Train not found." << endl;
    }

    void removeTrain(int trainNum) {
        Train* train = findTrain(trainNum);
        if (!train) {
            cout << "Train not found." << endl;
            return;
        }
        if (train->getPrev()) train->getPrev()->setNext(train->getNext());
        if (train->getNext()) train->getNext()->setPrev(train->getPrev());
        if (train == head) head = train->getNext();
        if (train == tail) tail = train->getPrev();
        delete train;
    }

    void findNextTrain(int currentTime) {
        Train* current = head;
        while (current) {
            if (current->getDepTime() >= currentTime) {
                cout << "Next train to depart: " << current->getTrainNum() << " at " << current->getDepTime() << endl;
                return;
            }
            current = current->getNext();
        }
        cout << "No upcoming trains." << endl;
    }

    void displayTrainsForRoute(string route) {
        Train* current = head;
        bool found = false;
        while (current) {
            if (current->getRoute() == route) {
                cout << "Train " << current->getTrainNum() << " departs at " << current->getDepTime() << endl;
                found = true;
            }
            current = current->getNext();
        }
        if (!found) cout << "No trains found for this route." << endl;
    }

    void reverseTraversal() {
        Train* current = tail;
        while (current) {
            cout << "Train " << current->getTrainNum() << " departed at " << current->getDepTime() << endl;
            current = current->getPrev();
        }
    }

    void updateRealTime(int currentTime) {
        Train* current = head;
        while (current) {
            if (current->getDepTime() < currentTime) current->setStatus("Departed");
            else if (current->getDepTime() == currentTime) current->setStatus("On Time");
            current = current->getNext();
        }
    }

    void rescheduleTrain(int trainNum, int newDepTime, int newArrTime) {
        Train* train = findTrain(trainNum);
        if (!train) {
            cout << "Train not found." << endl;
            return;
        }
        removeTrain(trainNum);
        train->setDepTime(newDepTime);
        train->setArrTime(newArrTime);
        insertSorted(train);
    }

    void optimizeRoutes() {
        Train* current = head;
        while (current && current->getNext()) {
            if (current->getDepTime() == current->getNext()->getDepTime() && 
                current->getRoute() == current->getNext()->getRoute()) {
                current->getNext()->setDepTime(current->getNext()->getDepTime() + 5);
                current->getNext()->setArrTime(current->getNext()->getArrTime() + 5);
            }
            current = current->getNext();
        }
    }

    void displayAllTrains() {
        Train* current = head;
        while (current) {
            cout << "Train " << current->getTrainNum() << " | Departure: " << current->getDepTime() 
                 << " | Arrival: " << current->getArrTime() << " | Route: " << current->getRoute() 
                 << " | Status: " << current->getStatus() << endl;
            current = current->getNext();
        }
    }
};

int main() {
    TrainSchedule schedule;
    int choice, trainNum, depTime, arrTime;
    string route, status;

    while (true) {
        cout << "\n1. Add Train\n2. Update Status\n3. Remove Train\n4. Find Next Train\n"
             << "5. Display Trains for Route\n6. Reverse Traversal\n7. Display All Trains\n"
             << "8. Real-time Update\n9. Reschedule Train\n10. Optimize Routes\n0. Exit\n"
             << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Enter Train Number, Departure Time, Arrival Time, Route, Status: ";
                cin >> trainNum >> depTime >> arrTime >> route >> status;
                schedule.addTrain(trainNum, depTime, arrTime, route, status);
                break;
            case 2:
                cout << "Enter Train Number and New Status: ";
                cin >> trainNum >> status;
                schedule.updateTrainStatus(trainNum, status);
                break;
            case 3:
                cout << "Enter Train Number to remove: ";
                cin >> trainNum;
                schedule.removeTrain(trainNum);
                break;
            case 4:
                cout << "Enter current time: ";
                cin >> depTime;
                schedule.findNextTrain(depTime);
                break;
            case 5:
                cout << "Enter Route: ";
                cin >> route;
                schedule.displayTrainsForRoute(route);
                break;
            case 6:
                schedule.reverseTraversal();
                break;
            case 7:
                schedule.displayAllTrains();
                break;
            case 8:
                cout << "Enter current time for real-time update: ";
                cin >> depTime;
                schedule.updateRealTime(depTime);
                break;
            case 9:
                cout << "Enter Train Number, New Departure Time, New Arrival Time: ";
                cin >> trainNum >> depTime >> arrTime;
                schedule.rescheduleTrain(trainNum, depTime, arrTime);
                break;
            case 10:
                schedule.optimizeRoutes();
                cout << "Routes optimized." << endl;
                break;
            case 0:
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    }
}