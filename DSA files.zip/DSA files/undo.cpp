#include <iostream>
#include <string>

using namespace std;

class Dependency {
public:
    int taskId;
    Dependency* next;

    Dependency(int id) : taskId(id), next(NULL) {}
};

class Task {
public:
    int id;
    string name;
    string description;
    bool completed;
    Dependency* dependencies;
    Task* next;
    Task* prev;

    Task(int i, string n, string d) : id(i), name(n), description(d), completed(false), dependencies(NULL), next(NULL), prev(NULL) {}

    ~Task() {
        while (dependencies) {
            Dependency* temp = dependencies;
            dependencies = dependencies->next;
            delete temp;
        }
    }
};

class TaskManager {
private:
    Task* head;
    Task* tail;
    Task* lastCompleted;
    Task* lastUndone;

    Task* findTask(int id) {
        Task* current = head;
        while (current) {
            if (current->id == id) return current;
            current = current->next;
        }
        return NULL;
    }

    bool checkDependencies(Task* task) {
        Dependency* dep = task->dependencies;
        while (dep) {
            Task* depTask = findTask(dep->taskId);
            if (depTask && !depTask->completed) return false;
            dep = dep->next;
        }
        return true;
    }

    void updateDependentTasks(Task* completedTask) {
        Task* current = head;
        while (current) {
            Dependency* dep = current->dependencies;
            while (dep) {
                if (dep->taskId == completedTask->id) {
                    cout << "Task " << current->id << " can now be started." << endl;
                    break;
                }
                dep = dep->next;
            }
            current = current->next;
        }
    }

public:
    TaskManager() : head(NULL), tail(NULL), lastCompleted(NULL), lastUndone(NULL) {}

    ~TaskManager() {
        while (head) {
            Task* temp = head;
            head = head->next;
            delete temp;
        }
    }

    void addTask(int id, string name, string description) {
        Task* newTask = new Task(id, name, description);
        if (!head) {
            head = tail = newTask;
        } else {
            tail->next = newTask;
            newTask->prev = tail;
            tail = newTask;
        }
    }

    void addDependency(int taskId, int dependencyId) {
        Task* task = findTask(taskId);
        if (task) {
            Dependency* newDep = new Dependency(dependencyId);
            newDep->next = task->dependencies;
            task->dependencies = newDep;
        }
    }

    bool completeTask(int id) {
        Task* task = findTask(id);
        if (task && !task->completed) {
            if (checkDependencies(task)) {
                task->completed = true;
                lastCompleted = task;
                lastUndone = NULL;
                updateDependentTasks(task);
                return true;
            } else {
                cout << "Cannot complete task. Dependencies not met." << endl;
            }
        }
        return false;
    }

    void undoCompletion() {
        if (lastCompleted) {
            lastCompleted->completed = false;
            lastUndone = lastCompleted;
            lastCompleted = NULL;
            cout << "Undid completion of task " << lastUndone->id << endl;
        } else {
            cout << "Nothing to undo." << endl;
        }
    }

    void redoCompletion() {
        if (lastUndone) {
            lastUndone->completed = true;
            lastCompleted = lastUndone;
            lastUndone = NULL;
            cout << "Redid completion of task " << lastCompleted->id << endl;
        } else {
            cout << "Nothing to redo." << endl;
        }
    }

    void viewTasks() {
        Task* current = head;
        while (current) {
            cout << "Task ID: " << current->id << ", Name: " << current->name 
                 << ", Status: " << (current->completed ? "Completed" : "Pending") << endl;
            cout << "Description: " << current->description << endl;
            cout << "Dependencies: ";
            Dependency* dep = current->dependencies;
            while (dep) {
                cout << dep->taskId << " ";
                dep = dep->next;
            }
            cout << endl << endl;
            current = current->next;
        }
    }

    void deleteTask(int id) {
        Task* task = findTask(id);
        if (task) {
            if (task->prev) task->prev->next = task->next;
            if (task->next) task->next->prev = task->prev;
            if (task == head) head = task->next;
            if (task == tail) tail = task->prev;

            // Remove this task from other tasks' dependencies
            Task* current = head;
            while (current) {
                Dependency* prev = NULL;
                Dependency* dep = current->dependencies;
                while (dep) {
                    if (dep->taskId == id) {
                        if (prev) prev->next = dep->next;
                        else current->dependencies = dep->next;
                        Dependency* temp = dep;
                        dep = dep->next;
                        delete temp;
                    } else {
                        prev = dep;
                        dep = dep->next;
                    }
                }
                current = current->next;
            }

            delete task;
            cout << "Task " << id << " deleted." << endl;
        } else {
            cout << "Task not found." << endl;
        }
    }
};

int main() {
    TaskManager tm;

    tm.addTask(1, "Design", "Create initial design");
    tm.addTask(2, "Development", "Implement core features");
    tm.addTask(3, "Testing", "Perform unit tests");
    tm.addTask(4, "Deployment", "Deploy to production");

    tm.addDependency(2, 1);
    tm.addDependency(3, 2);
    tm.addDependency(4, 3);

    cout << "Initial Task List:" << endl;
    tm.viewTasks();

    tm.completeTask(1);
    tm.completeTask(2);

    cout << "After completing Design and Development:" << endl;
    tm.viewTasks();

    tm.undoCompletion();

    cout << "After undoing last completion:" << endl;
    tm.viewTasks();

    tm.redoCompletion();

    cout << "After redoing completion:" << endl;
    tm.viewTasks();

    tm.deleteTask(2);

    cout << "After deleting Development task:" << endl;
    tm.viewTasks();

    return 0;
}