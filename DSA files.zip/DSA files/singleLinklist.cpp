#include<iostream>
using namespace std;

class Node {
private:
    int value;
    Node *next;
public:
    Node() : value(0), next(NULL) {}

    void setValue(int value){
        this->value = value;
    }
    void setNext(Node *next){
        this->next = next;
    }
    int getValue() {
        return value;
    }
    Node *getNext(){
        return next;
    }
};

class SingleLinkList {
private:
    Node *head;
    Node *current;
    int size;
public:
    SingleLinkList() : head(NULL), current(NULL), size(0) {}

    void insertHead(int value){
        Node *newNode = new Node();
        newNode->setValue(value);
        newNode->setNext(head);
        head = newNode;
        if(size == 0) {
            current = newNode;
        }
        size++;
    }

    void insertTail(int value){
        Node *newNode = new Node();
        newNode->setValue(value);
        newNode->setNext(NULL);
        if(head == NULL){
            head = newNode;
            current = newNode;
        }
        else {
            Node *temp = head;
            while(temp->getNext() != NULL){
                temp = temp->getNext();
            }
            temp->setNext(newNode);
            current = newNode;
        }
        size++;
    }

    void insertPosition(int value, int position){
        Node *newNode = new Node();
        newNode->setValue(value);
        if(position == 1){
            newNode->setNext(head);
            head = newNode;
            if(size == 0) {
                current = newNode;
            }
        }
        else{
            Node *temp = head;
            int count = 1;
            while(count < position - 1 && temp != NULL){
                temp = temp->getNext();
                count++;
            }
            if(temp == NULL){
                cout<<"Position doesn't exist"<<endl;
                return;
            }
            newNode->setNext(temp->getNext());
            temp->setNext(newNode);
            if(newNode->getNext() == NULL){
                current = newNode;
            }
        }
        size++;
    }

    void removeHead() {
        if(head == NULL){
            cout<<"List is empty"<<endl;
            return;
        }
        Node *temp = head;
        head = head->getNext();
        delete temp;
        size--;
        if(size == 0) {
            current = NULL;
        }
    }

    void removeTail(){
        if(head == NULL){
            cout<<"List is empty"<<endl;
            return;
        }
        else if(head->getNext() == NULL){
            delete head;
            head = NULL;
            current = NULL;
        }
        else {
            Node *temp = head;
            while(temp->getNext()->getNext() != NULL){
                temp = temp->getNext();
            }
            Node *lastNode = temp->getNext();
            temp->setNext(NULL);
            delete lastNode;
            current = temp;
        }
        size--;
    }

    void removePosition(int position){
        if(head == NULL){
            cout<<"List is empty"<<endl;
            return;
        }
        else if(position == 1){
            Node *temp = head;
            head = head->getNext();
            delete temp;
            size--;
            if(size == 0) {
                current = NULL;
            }
            return;
        }
        Node *temp = head;
        int count = 1;
        while(temp != NULL && count < position - 1){
            temp = temp->getNext();
            count++;
        }
        if(temp == NULL || temp->getNext() == NULL){
            cout<<"Position doesn't exist"<<endl;
            return;
        }
        Node *nodeToRemove = temp->getNext();
        temp->setNext(nodeToRemove->getNext());
        delete nodeToRemove;
        size--;
    }

    void reverseList(){
        Node *prev = NULL;
        Node *current = head;
        Node *next = NULL;
        while(current != NULL){
            next = current->getNext();
            current->setNext(prev);
            prev = current;
            current = next;
        }
        head = prev;
    }

    Node* nodeFromEnd(Node *head, int n){
        Node *p1 = head;
        Node *p2 = head;

        for(int i=0; i<n; i++){
            p2 = p2->getNext();
        }
        while(p2 != NULL){
            p1 = p1->getNext();
            p2 = p2->getNext();
        }
        return p1;
    }

    void insertBeforeHead(int value1, int value2){
        if(head == NULL || head->getNext() == NULL){
            cout<<"List is short to insert before end"<<endl;
            return;
        }
        Node *newNode1 = new Node();
        Node *newNode2 = new Node();
        newNode1->setValue(value1);
        newNode2->setValue(value2);
        //find the third last node
        Node *temp = head;
        while(temp->getNext()->getNext()->getNext() != NULL){
            temp = temp->getNext();
        }
        //insert new node
        newNode1->setNext(temp->getNext());
        temp->setNext(newNode1);
        newNode2->setNext(newNode1->getNext());
        newNode1->setNext(newNode2);

        size += 2;
    }

    void nextThreeNode(int value){
        if(head == NULL){
            cout<<"List is empty"<<endl;
            return;
        }
        Node *temp = head;
        bool found = false;
        //search key
        while(temp != NULL){
            if(temp->getValue() == value){
                found = true;
                break;
            }
            temp = temp->getNext();
        }
        if(!found){
            cout<<"Key value not found in the list"<<endl;
            return;
        }
        cout<<"Next nodes after key "<<value<<":"<<endl;
        for(int i=0; i<3 && temp->getNext() != NULL; i++){
            temp = temp->getNext();
            cout<<temp->getValue()<<" ";
        }
        cout<<endl;
    }

    void findPair(int n){
        if(n < 2){
            cout<<"Array size should be at least 2"<<endl;
            return;
        }
        int *arr = new int[n];
        cout<<"Enter "<<n<<" values:"<<endl;
        for(int i=0; i < n; i++){
            cin >> arr[i];
        }
        int maxProduct = INT_MIN;
        int maxi = 0, maxj = 1;
        for(int i=0; i<n; i++){
            for(int j= i+1; j<n; j++){
                int product = arr[i] * arr[j];
                if(product > maxProduct) {
                    maxProduct = product;
                    maxi = i;
                    maxj = j;
                }
            }
        }
        cout<<"The pair with maximum product is: "<<arr[maxi]<<" and "<<arr[maxj]<<endl;
        cout<<"Their product is: "<<maxProduct<<endl;
        delete[] arr;
    }

    void display(){
        Node *temp = head;
        while(temp != NULL){
            cout<<temp->getValue()<<" ";
            temp = temp->getNext();
        }
        cout<<endl;
    }
};

int main() {
    SingleLinkList sll;
    cout<<"Inserting elements:"<<endl;
    sll.insertHead(9);
    sll.insertHead(25);
    sll.insertHead(12);
    sll.insertTail(30);
    sll.insertPosition(25, 2);
    sll.display();

    cout<<"\nRemoving head and tail:"<<endl;
    sll.removeHead();
    sll.removeTail();
    sll.display();

    cout<<"\nReverse the list:"<<endl;
    sll.reverseList();
    sll.display();

    cout<<"\nInserting two nodes before end:"<<endl;
    sll.insertBeforeHead(22, 14);
    sll.display();

    cout<<"Finding next three nodes after 25:"<<endl;
    sll.nextThreeNode(25);

    cout<<"\nFinding pair with maximum product:"<<endl;
    sll.findPair(14);
    sll.display();

    return 0;
}