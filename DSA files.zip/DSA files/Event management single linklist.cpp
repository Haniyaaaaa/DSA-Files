#include<iostream>
using namespace std;

const int MAX_PARTICIPANTS = 50;

class Participant {
	private:
	int registrationID;
	string name;
	string email;
	string status;
	Participant *next;
	
	public:
	Participant(int id, string n, string e, string s) : registrationID(id), name(n), email(e), status(s), next(NULL) {}
    
    int getRegistrationID() {
    	return registrationID;
	}
	string getName(){
		return name;
	}
	string getEmail(){
		return email;
	}
	string getStatus(){
		return status;
	}
	Participant *getNext(){
		return next;
	}
	void setNext(Participant *n){
		next = n;
	}
	void setStatus(string s){
		status = s;
	}
};

class EventManagement {
	private:
    Participant *registeredList;
    Participant *waitingList;
    int registeredCount;
		
    public:
    	EventManagement() : registeredList(NULL), waitingList(NULL), registeredCount(0) {}

	void registerParticipant(string n, string e) {
		if(registeredCount < MAX_PARTICIPANTS) {
			Participant *newParticipant = new Participant(registeredCount + 1, n, e, "Registered");
			newParticipant -> setNext(registeredList);
			registeredList = newParticipant;
			registeredCount++;
			cout<<"Participant Registered"<<endl;
		}
		else {
			Participant *newParticipant = new Participant(0, n , e, "Waiting");
			newParticipant -> setNext(waitingList);
			waitingList = newParticipant;
			cout<<"Participant added to waiting list"<<endl;
		}
	}
	
	void cancelRegistration(int registrationID) {
		Participant *prev = NULL;
		Participant *current = registeredList;
		
		while(current != NULL) {
			if(current -> getRegistrationID() == registrationID && current ->getStatus() == "Registered" ) {
				if(prev == NULL) {
					registeredList = current -> getNext();
				}
				else {
					prev -> setNext(current -> getNext());
				}
				delete current;
				registeredCount--;
				
				Participant *waitingParticipant = waitingList;
				if(waitingParticipant != NULL) {
					waitingParticipant -> setStatus("Registered");
						registeredCount;
						cout<<"Registration Cancelled. Participant from wating list moved to registered status" <<endl;
					}
				else {
				cout<<"Regisiration cancelled. No participant is in the waiting list"<<endl;
		        return;
			}
			prev = current ;
			current = current -> getNext();
		}
		cout <<"Registration ID not found"<<endl;
	}
}
	void displayList(){
		cout<<"Registered list"<<endl;
		Participant *current = registeredList;
		while (current != NULL) {
				cout<<"ID:" << current->getRegistrationID() << ", NAME:" << current->getName() << ",Email:" << current->getEmail() << ", Status " << current->getStatus()<<endl;			
		        current = current -> getNext();
		}
		cout<<"Waiting List: "<<endl;
		current = waitingList;
		while(current != NULL) {
			cout<<"ID: "<<current->getRegistrationID() <<", Name: "<<current->getName() <<", Email: "<<current->getEmail() <<", Status: " <<current->getStatus() <<endl;
			current = current->getNext();
		}
    }
    
	void searchByEmail(string email) {
		Participant *current = registeredList;
		while (current != NULL ) {
			if(current -> getEmail() == email ) {
				cout<<"Participant Found:" <<endl;
				cout<<"ID:" << current->getRegistrationID() << ", NAME:" << current->getName() << ",Email:" << current->getEmail() << ", Status: " << current->getStatus() <<endl;	
				return;
			}
			current = current -> getNext();
		}
		current = waitingList;
		while(current != NULL) {
			if(current -> getEmail() == email) {
				cout<<"Participant Found:" <<endl;
				cout<<"ID:" << current->getRegistrationID() << ", NAME:" << current->getName() << ",Email:" << current->getEmail() << ", Status: " << current->getStatus() <<endl;	
				return;
			}
			current = current -> getNext();
		}
		cout<<"Participant not found"<<endl;
	}

};
 
 int main () {
 	EventManagement em;
 	
 	int choice;
 	string name, email;
 	int registrationID;
 	
 	do{
 		cout<<"\n-----Event Management System Menu-----\n";
 		cout<<"1. Register a Participant\n";
 		cout<<"2. Cancel a Registration\n";
 		cout<<"3. Search by email\n";
 		cout<<"4. Display Participants\n";
 		cout<<"5. Exit\n";
 		cout<<"Enter your choice: ";
 		cin>>choice;
 		
 		switch (choice) {
 			case 1:
 				cout<<"Enter Name: ";
 				cin>>name;
 				cout<<"Enter Email: ";
 				cin>>email;
 				em.registerParticipant(name, email);
 				break;
 				
 			case 2:
 				cout<<"Enter Registration ID to cancel: ";
 				cin>>registrationID;
 				em.cancelRegistration(registrationID);
 				break;
 				
 			case 3:
 				cout<<"Enter email to search: ";
 				cin>>email;
 				em.searchByEmail(email);
 				break;
 				
 			case 4:
 				em.displayList();
 				break;
 			
 			case 5:
 				cout<<"Exiting event management system. GOODBYE\n";
 				break;
 			
 			default:
 				cout<<"Invalid Choice\n";
 				break;
		 }
	 } while (choice != 5);
	 
	 return 0;
}
