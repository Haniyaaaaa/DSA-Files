#include<iostream>
#include "Linked list.cpp"
using namespace std;

int main(){
	LinkedList listSecA;
	listSecA.insert(100);
	listSecA.insert(60);
}