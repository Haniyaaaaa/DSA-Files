#include <iostream>
#include <string>

using namespace std;

// Node structure
struct Node {
    int processID;
    string processName;
    int executionTime;
    int remainingBurstTime;
    Node* next;
};

// CPU Round-Robin Scheduling System class
class CPURoundRobinScheduling {
private:
    Node* head;
    int timeQuantum;

public:
    CPURoundRobinScheduling(int timeQuantum) {
        head = nullptr;
        this->timeQuantum = timeQuantum;
    }

    // Add a new process to the scheduling queue
    void addProcess(int processID, string processName, int executionTime) {
        Node* newNode = new Node();
        newNode->processID = processID;
        newNode->processName = processName;
        newNode->executionTime = executionTime;
        newNode->remainingBurstTime = executionTime;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
            head->next = head;
        } else {
            Node* current = head;
            while (current->next != head) {
                current = current->next;
            }
            current->next = newNode;
            newNode->next = head;
        }
    }

    // Simulate round-robin scheduling
    void simulateRoundRobinScheduling() {
        Node* current = head;
        while (current != nullptr) {
            if (current->remainingBurstTime > 0) {
                int timeSlice = min(timeQuantum, current->remainingBurstTime);
                current->remainingBurstTime -= timeSlice;
                cout << "Process " << current->processID << " (" << current->processName << ") executed for " << timeSlice << " units." << endl;
                if (current->remainingBurstTime == 0) {
                    Node* temp = current;
                    current = current->next;
                    removeProcess(temp);
                } else {
                    current = current->next;
                }
            } else {
                current = current->next;
            }
        }
    }

    // Display all active processes
    void displayProcesses() {
        Node* current = head;
        cout << "Active Processes:" << endl;
        do {
            cout << "Process " << current->processID << " (" << current->processName << "): Remaining Burst Time = " << current->remainingBurstTime << endl;
            current = current->next;
        } while (current != head);
    }

    // Remove a process from the scheduling queue
    void removeProcess(Node* process) {
        if (head == process) {
            head = head->next;
        }
        Node* current = head;
        while (current->next != process) {
            current = current->next;
        }
        current->next = process->next;
        delete process;
    }

    // Check if the CPU is idle
    bool isCPUIdle() {
        return head == nullptr;
    }
};

int main() {
    CPURoundRobinScheduling schedulingSystem(2); // Time quantum = 2 units

    while (true) {
        cout << "1. Add a new process" << endl;
        cout << "2. Simulate round-robin scheduling" << endl;
        cout << "3. Display all active processes" << endl;
        cout << "4. Exit" << endl;

        int choice;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                int processID;
                string processName;
                int executionTime;

                cout << "Enter process ID: ";
                cin >> processID;

                cout << "Enter process name: ";
                cin >> processName;

                cout << "Enter execution time: ";
                cin >> executionTime;

                schedulingSystem.addProcess(processID, processName, executionTime);
                break;
            }
            case 2:
                schedulingSystem.simulateRoundRobinScheduling();
                break;
            case 3:
                schedulingSystem.displayProcesses();
                break;
            case 4:
                return 0;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }

        if (schedulingSystem.isCPUIdle()) {
            cout << "CPU is idle. Waiting for new processes..." << endl;
        }
    }

    return 0;
}