#include<iostream>
#include<string>
#include<ctime>
using namespace std; 

class webPage {
	public:
		string url;
		string title;
		time_t timestamp;
		webPage *prev;
		webPage *next;
	
	   webPage() : timestamp(time(nullptr)), prev(nullptr), next(nullptr) {}
	
    string getUrl() { 
	return url; 
	}
    string getTitle() { 
	return title; 
	}
    time_t getTimestamp() {
	 return timestamp;
	  }
    webPage* getPrev() {
	 return prev; 
	 }
    webPage* getNext() {
	 return next; 
	 }

    // Setter methods
    void setUrl(string u) { 
	url = u; 
	}
    void setTitle(string t) {
	 title = t; 
	 }
    void setTimestamp(time_t t) {
	 timestamp = t; 
	 }
    void setPrev(webPage* p) {
	 prev = p; 
	 }
    void setNext(webPage* n) { 
	next = n; 
	}
};

class browserHistory {
	private:
		webPage *current;
		webPage *head;
		webPage *tail;
   
   webPage *findPage(string url){
   	webPage *temp = head;
   	while(temp) {
   		if(temp -> url == url) {
   			return temp;
		   }
		   temp = temp->next;
	   }
	   return NULL;
   }
   
   void removePage(webPage *page){
   	if(page -> prev) {
   		page ->prev -> next = page -> next;
	   }
	   else {
	   	head = page -> next;
	   }
	   if(page -> next) {
	   	page -> next -> prev = page -> prev;
	   }
	   else {
	   	tail = page -> prev;
	   }
   }	
   
   void displayCurrentPage() {
   	if(current) {
   		cout <<"Current Page - URL: " <<current->url <<", Title:" <<current->title <<", Timestamp:" <<ctime(&current->timestamp);
	   }
	   else {
	   	cout<<"No current page.\n";
	   }
   }
   
		
	public:
		browserHistory() : current(NULL), head(NULL), tail(NULL) {}
		
		~browserHistory() {
			clearHistory();
		}
		
    void visitPage(string url, string title) {
    webPage *newPage = new webPage();
    newPage->url = url;
    newPage->title = title;

    if (!head) {
        head = tail = current = newPage;
    } else {
        webPage *existingPage = findPage(url);
        if (existingPage) {
            removePage(existingPage);
            delete existingPage;
        }
        
        newPage->prev = current;
        newPage->next = current->next;
        if (current->next) {
            current->next->prev = newPage;
        } else {
            tail = newPage;
        }
        
        current->next = newPage;
        current = newPage;
        
        while (current->next) {
            webPage *temp = current->next;
            current->next = temp->next;
            if (temp->next) {
                temp->next->prev = current;
            } else {
                tail = current;
            }
            delete temp;
        }
    }
}	
   
   bool goBack() {
   	if(current && current -> prev) {
   		current = current -> prev;
   		displayCurrentPage();
   		return true;
	   }
	   return false;
   }
   
   bool goForward() {
   	if(current && current -> next) {
   		current = current -> next;
   		displayCurrentPage();
   		return true;
	   }
	   return false;
   }
   
   void displayHistory() {
   	if(!head){
   		cout<<"History is empty.\n";
   		return;
	   }
   	webPage *temp = head;
   	while(temp) {
   		cout<<"URL:" <<temp->url <<", Title:" <<temp->title <<", Timestamp: " <<ctime(&temp->timestamp);
   		temp = temp->next;
	   }
   }
   
   void deletePage(string url){
   	webPage *page = findPage(url);
   	if(page) {
   		removePage(page);
   		if(page == current) {
   			if(current -> next) {
   				current = current -> next;
			   } else if(current -> prev){
			   	current = current -> prev;
			   } else {
			   	current = NULL;
			   }
		   }
		   delete page;
	   }
   }
   
   void clearHistory() {
   	while(head) {
   		webPage *temp = head;
   		head = head -> next;
   		delete temp;
	   }
	   head = tail = current = NULL;
   }
   
void searchHistory() {
    int choice;
    cout << "Search by:\n1. URL\n2. Title\n";
    cin >> choice;

    if (choice == 1) {
        string url;
        cout << "Enter URL: ";
        cin >> url;
        webPage *page = findPage(url);
        if (page) {
            cout << "URL: " << page->url << ", Title: " << page->title << ", Timestamp: " << ctime(&page->timestamp);
        } else {
            cout << "Page not found.\n";
        }
    } else if (choice == 2) {
        string title;
        cout << "Enter Title: ";
        cin.ignore();
        getline(cin, title);
        webPage *temp = head;
        bool found = false;
        while (temp) {
            if (temp->title == title) {
                cout << "URL: " << temp->url << ", Title: " << temp->title << ", Timestamp: " << ctime(&temp->timestamp);
                found = true;
            }
            temp = temp->next;
        }
        if (!found) {
            cout << "Page not found.\n";
        }
    } else {
        cout << "Invalid choice.\n";
    }
}
   
};

int main() {
	browserHistory bh;
	
	cout<<"Adding pages to history...\n";
	bh.visitPage("https://www.youtube.com", "YOUTUBE");
	bh.visitPage("https://www.shykhcrypto.com", "shykhcrypto");
	bh.visitPage("https://www.instagram.com", "instragram");
	
	cout<<"Current history:\n";
	bh.displayHistory();
	
	cout<<"\nGoing back:\n";
	if(bh.goBack()) {
		cout<<"Went back successfully.\n";
	} else {
		cout<<"Couldn't go back.\n";
	}
	
	cout<<"\nGoing forward:\n";
	if(bh.goForward()) {
     	cout<<"Went forward successfully.\n";
	} else {
		cout<<"Couldn't go forword.\n";
	}
	
	cout<<"\nVisting a new page:\n";
	bh.visitPage("https://www.hudabeauty.com", "hudabeauty");
	
	cout<<"\nUpdated History:\n";
	bh.displayHistory();
	
	//cout<<"\nSearching for shykhCrypto:\n";
	bh.searchHistory();
	
	cout<<"\nDeleting 'Youtube' page:\n";
	bh.deletePage("https://www.youtube.com");
	
	cout<<"Updated history after deletion:\n";
	bh.displayHistory();
	
	cout<<"\nClearing history:\n";
	bh.clearHistory();
	
	cout<<"History after clearing:\n";
	bh.displayHistory();
	
	return 0;
}