#include <iostream>
#include <string>

using namespace std;

const int MAX = 100;

class Stack {
    char data[MAX];
    int top;

public:
    Stack() : top(-1) {}

    void push(char x) {
        if (top < MAX - 1) data[++top] = x;
    }

    char pop() {
        return (top >= 0) ? data[top--] : '\0';
    }

    char peek() {
        return (top >= 0) ? data[top] : '\0';
    }

    bool empty() {
        return top == -1;
    }
};

int precedence(char c) {
    if (c == '+' || c == '-') return 1;
    if (c == '*' || c == '/') return 2;
    if (c == '^') return 3;
    return 0;
}

string convert(string in) {
    Stack s;
    string out;
    
    for (char c : in) {
        if (isalnum(c)) {
            out += c;
        } else if (c == '(') {
            s.push(c);
        } else if (c == ')') {
            while (!s.empty() && s.peek() != '(') {
                out += s.pop();
            }
            if (!s.empty() && s.peek() == '(') {
                s.pop();
            }
        } else {
            while (!s.empty() && precedence(c) <= precedence(s.peek())) {
                out += s.pop();
            }
            s.push(c);
        }
    }
    
    while (!s.empty()) {
        out += s.pop();
    }
    
    return out;
}

int main() {
    string expr;
    cout << "Enter expression: ";
    getline(cin, expr);
    
    string result = convert(expr);
    cout << "Result: " << result << endl;
    
    return 0;
}