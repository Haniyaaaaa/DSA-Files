#include <iostream>

using namespace std;

const int MAX = 100;

class StackArr {
private:
    int top;
    int arr[MAX];

public:
    StackArr() : top(-1) {}

    void push(int x) {
        if (top < MAX - 1) arr[++top] = x;
        else cout << "Stack full!\n";
    }

    int pop() {
        if (top >= 0) return arr[top--];
        cout << "Stack empty!\n";
        return -1;
    }

    bool empty() { return top == -1; }
};

class QueueArr {
private:
    int front, rear;
    int arr[MAX];

public:
    QueueArr() : front(-1), rear(-1) {}

    void add(int x) {
        if (rear < MAX - 1) {
            if (front == -1) front = 0;
            arr[++rear] = x;
        } else cout << "Queue full!\n";
    }

    int remove() {
        if (front <= rear && front != -1) {
            int x = arr[front++];
            if (front > rear) front = rear = -1;
            return x;
        }
        cout << "Queue empty!\n";
        return -1;
    }

    bool empty() { return front == -1; }
};

struct Node {
    int data;
    Node* next;
    Node(int x) : data(x), next(nullptr) {}
};

class StackList {
private:
    Node* top;

public:
    StackList() : top(nullptr) {}

    void push(int x) {
        Node* newNode = new Node(x);
        newNode->next = top;
        top = newNode;
    }

    int pop() {
        if (top) {
            int x = top->data;
            Node* temp = top;
            top = top->next;
            delete temp;
            return x;
        }
        cout << "Stack empty!\n";
        return -1;
    }

    bool empty() { return top == nullptr; }
};

class QueueList {
private:
    Node *front, *rear;

public:
    QueueList() : front(nullptr), rear(nullptr) {}

    void add(int x) {
        Node* newNode = new Node(x);
        if (!rear) front = rear = newNode;
        else {
            rear->next = newNode;
            rear = newNode;
        }
    }

    int remove() {
        if (front) {
            int x = front->data;
            Node* temp = front;
            front = front->next;
            if (!front) rear = nullptr;
            delete temp;
            return x;
        }
        cout << "Queue empty!\n";
        return -1;
    }

    bool empty() { return front == nullptr; }
};

void test() {
    StackArr s1;
    QueueArr q1;
    StackList s2;
    QueueList q2;

    cout << "Testing StackArr:\n";
    s1.push(10);
    s1.push(20);
    cout << s1.pop() << endl;
    cout << s1.pop() << endl;
    cout << s1.empty() << endl;

    cout << "\nTesting QueueArr:\n";
    q1.add(30);
    q1.add(40);
    cout << q1.remove() << endl;
    cout << q1.remove() << endl;
    cout << q1.empty() << endl;

    cout << "\nTesting StackList:\n";
    s2.push(50);
    s2.push(60);
    cout << s2.pop() << endl;
    cout << s2.pop() << endl;
    cout << s2.empty() << endl;

    cout << "\nTesting QueueList:\n";
    q2.add(70);
    q2.add(80);
    cout << q2.remove() << endl;
    cout << q2.remove() << endl;
    cout << q2.empty() << endl;
}

int main() {
    test();
    return 0;
}