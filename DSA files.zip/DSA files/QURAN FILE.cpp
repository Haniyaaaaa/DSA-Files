#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cerrno>
#include <cstring>

using namespace std;

void readSurah(int surahNumber) {
    string fileName = "C:\\Users\\Hamza Computer\\Desktop\\Quran.txt"; // Adjust if needed
    ifstream quranFile(fileName);

    if (!quranFile) {
        cerr << "Error: Unable to open file '" << fileName << "'" << endl;
        cerr << "Make sure the file exists at this location." << endl;
        cerr << "Error Code: " << strerror(errno) << endl; // Print the error code
        return;
    }

    string line;
    cout << "\nDisplaying Surah " << surahNumber << ":\n" << endl;
    
    bool surahFound = false;
    while (getline(quranFile, line)) {
        stringstream ss(line);
        string surah, ayah, text;
        
        getline(ss, surah, '|');
        getline(ss, ayah, '|');
        getline(ss, text);
        
        if (stoi(surah) == surahNumber) {
            cout << ayah << ". " << text << endl;
            surahFound = true;
        } else if (surahFound) {
            break; // Stop reading after the desired surah is complete
        }
    }

    if (!surahFound) {
        cout << "Surah " << surahNumber << " not found in the file." << endl;
    }

    quranFile.close();
}

int main() {
    int surahNumber;
    char choice;

    do {
        cout << "Enter Surah number (1-114): ";
        cin >> surahNumber;

        if (surahNumber < 1 || surahNumber > 114) {
            cout << "Invalid Surah number! Please enter a number between 1 and 114.\n";
        } else {
            readSurah(surahNumber);
        }

        cout << "\nWould you like to read another Surah? (y/n): ";
        cin >> choice;
    } while (choice == 'y' || choice == 'Y');

    cout << "Thank you for using the Quran Reader." << endl;
    return 0;
}
